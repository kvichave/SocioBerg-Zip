var menuli = document.getElementById('sidemenu')
console.log(menuli);
