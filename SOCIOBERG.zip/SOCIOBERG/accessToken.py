import requests,json
import sqlite3 




def accessToken(code,forApp):

    if forApp=='instagram':
        accessUrl='https://graph.facebook.com/v18.0/oauth/access_token?client_id=1392141388101711&redirect_uri=https://127.0.0.1:5000/success?for=instagram&client_secret=bf1260d487a10744bf2aa02eb24326c5&code='+code
        response=requests.get(accessUrl)
        data=response.json()
        # print("data ::::: ",data)

        connect = sqlite3.connect('socio.db') 
        cursor = connect.cursor() 
        cursor.execute("SELECT DISTINCT forApp FROM Access_code WHERE username='kunal'") 
        # print("inside else")
        accessFor = cursor.fetchall()
        # print("accessFor ==  ",accessFor)
        

        if data.get('access_token', 'None') !="None":
            # print("inside if")
            # print("[item for item in accessFor if item==('instagram',)] === ",[item for item in accessFor if item==('instagram',)])
            
            if not accessFor or [item for item in accessFor if item==('instagram',)] != [('instagram',)]:
                # print("if inside iff")
                ACCESS_TOKEN=data['access_token']
                # print("Accccccccess === ",ACCESS_TOKEN)
                with sqlite3.connect("socio.db") as users: 
                    cursor = users.cursor() 
                    cursor.execute("INSERT INTO Access_code (username,access_code,forApp) VALUES (?,?,?)", 
                                ("kunal", ACCESS_TOKEN,forApp)) 
                    users.commit() 
                print("Access token from if : ",ACCESS_TOKEN)
                return(ACCESS_TOKEN)
            else:
                return data.get('access_token')
            
            
        else:
            connect = sqlite3.connect('socio.db') 
            cursor = connect.cursor() 
            cursor.execute("SELECT access_code FROM Access_code WHERE username = 'kunal' AND forApp = 'instagram'") 
            # print("inside else")
            ACCESS_TOKEN = cursor.fetchall()[0][0]
            print("access token from else : ",ACCESS_TOKEN)
            return ACCESS_TOKEN

            # print("Access Token is :::::::: ",ACCESS_TOKEN)