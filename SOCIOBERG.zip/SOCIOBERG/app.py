from flask import Flask,render_template,redirect,request,url_for,json,session
from flask_oauthlib.client import OAuth
from credentials import CLIENT_ID,CLIENT_SECRET
import sqlite3

import requests
from socioberg_auth import socio_signup,socio_login

app = Flask(__name__)
app.secret_key = CLIENT_SECRET  # Replace with a secure secret key
app.config['PERMANENT_SESSION_LIFETIME'] = 10 * 365 * 24 * 60 * 60  # 10 years in seconds




@app.route('/',methods=['GET','POST'])
def home():
    if 'username' in session:
        return render_template('home.html')
    

    else:
        return login()



@app.route('/signup',methods=['GET','POST'])
def signup():
    if 'username' in session:
        return render_template('home.html')

    if request.form.get('username'):
        username=request.form.get('username')
        email=request.form.get('email')
        password=request.form.get('password')
        print(username,email,password)
        user=socio_signup(username,email,password)
        if user =="email" or user=="username":
            return render_template('signup.html',error=user)
        session["username"]=user
        return render_template('home.html')



        

  
    return render_template('signup.html')




@app.route('/login',methods=['GET','POST'])
def login():
    if 'username' in session:
        return render_template('home.html')
    
    if request.form.get('email'):
        password=request.form.get('password')
        email=request.form.get('email')  

        user=socio_login(email,password)
        if user=="None":
            return render_template('login.html',error="Invalid Credential")
        session["username"]=user
        return redirect(url_for('home'))

        
    
    return render_template('login.html')


@app.route('/logout')
def logout():
    # Clear the session to destroy it
    session.clear()
    return redirect(url_for('home'))









if __name__ == '__main__':
    app.run(ssl_context='adhoc',debug=True)